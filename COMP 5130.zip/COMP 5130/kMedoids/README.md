# kMedoids
UG4 -

Run code by: 
1. ensuring data set is pointing to correct place
2. copying data set in the code where specified
3. open terminal or command line
4. find folder with code
5. in command line type python mainkM.py
