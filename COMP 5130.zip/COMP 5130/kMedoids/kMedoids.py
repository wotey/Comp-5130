import random
import numpy

def kMedoids(distanceM, k, p=100):
    
    rows, cols = distanceM.shape#fix distance matrix     
    VM = set(range(cols))
    inVM = set([])
    row,col = numpy.where(distanceM==0)    
    i = list(range(len(row)))
    numpy.random.shuffle(i)          
    row = row[i]
    col = col[i]
      
    if k > cols:
        raise Exception('not right, back up')

    inVM = invalid(row, col, inVM)
    VM = list(VM - inVM)

    if k > len(VM):
        raise Exception('removed {} data values'.format(len(inVM)))
    matrix = numpy.array(VM)
    numpy.random.shuffle(matrix)
    matrix = numpy.sort(matrix[:k])

    newMedoid = numpy.copy(matrix)
    
    H = clustering(matrix, distanceM, k, p)
    # return results
    return matrix, H

#make the clusters
def clustering(matrix, distanceM, k, p):
    clusters = {} #hold the clusters for k clusters
    newMedoid = numpy.copy(matrix) #hold the medoids
    for nums in range(p):
        checked = numpy.argmin(distanceM[:,matrix], axis=1)
        for kap in range(k):
            clusters[kap] = numpy.where(checked==kap)[0]
        for kap in range(k):
            checked = numpy.mean(distanceM[numpy.ix_(clusters[kap],clusters[kap])],axis=1)
            hap = numpy.argmin(checked)
            newMedoid[kap] = clusters[kap][hap]
        numpy.sort(newMedoid)
        if (matrix == newMedoid).all(): #if medoids did not change that's the end of it
            break 
        matrix = numpy.copy(newMedoid)
    else:
        checked = numpy.argmin(distanceM[:,matrix], axis=1)
        for kap in range(k):
            clusters[kap] = numpy.where(checked==kap)[0]
    return clusters

def invalid(row, col, invalidlist):
    for r,c in zip(row,col):
        if r < c and r not in invalidlist:
            invalidlist.add(c)
    return invalidlist
