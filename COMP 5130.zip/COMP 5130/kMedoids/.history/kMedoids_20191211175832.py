import numpy
import random

def kMedoids(D, k, tmax=100):
    # determine dimensions of distance matrix D
    rows, n = D.shape

    if k > n:
        raise Exception('too many medoids')

    # find a set of valid initial cluster medoid indices since we
    # can't seed different clusters with two points at the same location
    valid_medoid_inds = set(range(n))
    invalid_medoid_inds = set([])
    rs,cs = numpy.where(D==0)
    # the rows, cols must be shuffled because we will keep the first duplicate below
    index_shuf = list(range(len(rs)))
    numpy.random.shuffle(index_shuf)
    rs = rs[index_shuf]
    cs = cs[index_shuf]

    invalid_medoid_inds = invalid(rs, cs, invalid_medoid_inds)
    valid_medoid_inds = list(valid_medoid_inds - invalid_medoid_inds)

    if k > len(valid_medoid_inds):
        raise Exception('too many medoids (after removing {} duplicate points)'.format(
            len(invalid_medoid_inds)))

    # randomly initialize an array of k medoid indices
    M = numpy.array(valid_medoid_inds)
    numpy.random.shuffle(M)
    M = numpy.sort(M[:k])

    # create a copy of the array of medoid indices
    Mnew = numpy.copy(M)

    # initialize a dictionary to represent clusters
    C = {}
    for t in range(tmax):
        # determine clusters, i. e. arrays of data indices
        J = numpy.argmin(D[:,M], axis=1)
        for kappa in range(k):
            C[kappa] = numpy.where(J==kappa)[0]
        # update cluster medoids
        for kappa in range(k):
            J = numpy.mean(D[numpy.ix_(C[kappa],C[kappa])],axis=1)
            j = numpy.argmin(J)
            Mnew[kappa] = C[kappa][j]
        numpy.sort(Mnew)
        # check for convergence
        if numpy.array_equal(M, Mnew):
            break
        M = numpy.copy(Mnew)
    else:
        # final update of cluster memberships
        J = numpy.argmin(D[:,M], axis=1)
        for kappa in range(k):
            C[kappa] = numpy.where(J==kappa)[0]

    # return results
    return M, C

def invalid(rs, cs, invalidlist):
    for r,c in zip(rs,cs):
        # if there are two points with a distance of 0...
        # keep the first one for cluster init
        if r < c and r not in invalidlist:
            invalidlist.add(c)
    return invalidlist